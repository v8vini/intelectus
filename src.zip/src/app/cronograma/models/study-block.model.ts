export interface StudyBlock {
  id: number;
  dia: string;
  horario: string;
  disciplina: string;
  duracao: string;
  descricao: string;
}
