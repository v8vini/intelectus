import { Component } from '@angular/core';

@Component({
  selector: 'app-bloco-estudo',
  imports: [],
  templateUrl: './bloco-estudo.html',
  styleUrl: './bloco-estudo.css',
})
export class BlocoEstudo {

}
