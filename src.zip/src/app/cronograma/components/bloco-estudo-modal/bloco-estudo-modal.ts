import { Component } from '@angular/core';

@Component({
  selector: 'app-bloco-estudo-modal',
  imports: [],
  templateUrl: './bloco-estudo-modal.html',
  styleUrl: './bloco-estudo-modal.css',
})
export class BlocoEstudoModal {

}
